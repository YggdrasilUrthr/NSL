rm -rf output.*
rm -rf seed.out
rm -rf config.final
